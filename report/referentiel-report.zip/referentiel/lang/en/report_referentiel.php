<?php
// referentiel module
// Moodle 2
$string['pluginname'] = 'Skills repository';

?>
