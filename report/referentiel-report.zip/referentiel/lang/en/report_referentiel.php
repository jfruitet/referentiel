<?php
// referentiel module
// Moodle 2
$string['pluginname'] = 'Skills repository';
$string['rank'] = 'Rank';
$string['etudiants_inscrits_referentiel'] = 'Registered Students in any certification process';
$string['actualisation'] = 'Update students\' numbers from User profile';
$string['profilcheck'] = 'The modifications in Students numbers Profile will be set in Referential Student table...';
?>
