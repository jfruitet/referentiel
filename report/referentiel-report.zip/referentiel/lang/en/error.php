<?php
// referentiel module

// 6.0
$string['unknowformat'] = 'Data format unknown: {$a}';
?>
