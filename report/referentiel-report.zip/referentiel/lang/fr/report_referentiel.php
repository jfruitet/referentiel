<?php
// ----------------
// UTF-8 French

// Moodle 2
$string['pluginname'] = 'Référentiel';

?>
