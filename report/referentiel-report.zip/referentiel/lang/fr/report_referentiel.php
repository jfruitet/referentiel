<?php
// ----------------
// UTF-8 French

// Moodle 2
$string['pluginname'] = 'Référentiel';
$string['rank'] = 'Rang';
$string['etudiants_inscrits_referentiel'] = 'Etudiants inscrits dans des processus de certification';
$string['actualisation'] = 'Actualiser les numéro d\'étudiant d\'après le Profil utilisateur';
$string['profilcheck'] = 'Les modifications de numéro d\'étudiant intervenues dans les profils utilisateurs
seront prises en compte...';

?>
