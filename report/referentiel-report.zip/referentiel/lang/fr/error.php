<?php
// referentiel module

// 6.0
$string['unknowformat'] = 'Format de donné inconnu : {$a}';
?>
