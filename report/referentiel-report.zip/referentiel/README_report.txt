Moodle module referentiel 
Module Moodle - R�f�rentiel / Pository - Documentation
jean.fruitet@univ-nantes.fr
2007/2013

Type: Activity Module
Requires: Moodle 1.8 / 1.9 or later
Status: Contributed
Maintainer(s): jean.fruitet@univ-nantes.fr

Moodle 1.9, 2.0, 2.1
--------------------
L'archive referentiel-report_m19.zip (referentiel-report_m21.zip)
doit �tre d�comprim�e dans le dossier
SERVEUR_MOODLE/admin/report/


Moodle 2.2, 2.3, 2.4
--------------------
L'archive referentiel-report.zip
doit �tre d�comprim�e dans le dossier
SERVEUR_MOODLE/report/

L'administrateur a alors la possibilit� de g�rer les occurrences, les instances  et les archives
du module r�f�rentiel de son serveur depuis la rubrique "Rapports" sans passer par une instance de cours.

2013/04/04 : J'ai ajout� la possibilit� d'afficher les d�clarations non �values depuis plus de 28 jours.